var classRibbonDecorator =
[
    [ "RibbonDecorator", "dc/d53/classRibbonDecorator.html#a5b56ae50e938fb651f793209af9dab23", null ],
    [ "~RibbonDecorator", "dc/d53/classRibbonDecorator.html#a4c16a7d139f037d333b7a07cfa02bfb2", null ],
    [ "blueprintClone", "dc/d53/classRibbonDecorator.html#a9896fbacd6790205ecb5fe629a2725ab", null ],
    [ "clone", "dc/d53/classRibbonDecorator.html#a66592f736489a4e68fb19667a823a4b5", null ],
    [ "deserialize", "dc/d53/classRibbonDecorator.html#a89fbd40e3be87405379d2b4764daa508", null ],
    [ "getName", "dc/d53/classRibbonDecorator.html#a057b4f35bb10e09bfda0fa85a84cace0", null ],
    [ "getPrice", "dc/d53/classRibbonDecorator.html#a9826ee8ae255f9dbef2120c4bd6085a7", null ],
    [ "serialize", "dc/d53/classRibbonDecorator.html#a714d4eb703e94869e810fbe135d93bcc", null ],
    [ "typeName", "dc/d53/classRibbonDecorator.html#aee9f47ae96da181bb3f45e4b9451384c", null ]
];