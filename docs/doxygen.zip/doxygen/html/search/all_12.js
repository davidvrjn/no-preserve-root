var searchData=
[
  ['ui_506',['UI',['../d6/d56/namespaceUI.html',1,'']]],
  ['update_507',['update',['../dd/d93/classNurserySupervisor.html#a6fdf4bb52f28d36cfe725db7dceebe27',1,'NurserySupervisor::update()'],['../de/dab/classObserver.html#af97fc9d0942e9610d0f83bc2f0077346',1,'Observer::update()']]]
];
