var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwy~",
  1: "abcdfgilmnoprstw",
  2: "du",
  3: "abcdfgilmnoprstw",
  4: "abcdefghilmnoprstuvw~",
  5: "abcdefghiklmnoprstw",
  6: "gprsw",
  7: "cdfghilmnprsvwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator"
};

