var searchData=
[
  ['year_5fround_1272',['YEAR_ROUND',['../d1/d69/PlantAttributes_8h.html#ace3a72289effba7c41de4a566bd3c300aa722f29cb3894d5949e4ff0bc65e0435',1,'PlantAttributes.h']]]
];
