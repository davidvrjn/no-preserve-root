var searchData=
[
  ['winter_1271',['WINTER',['../d1/d69/PlantAttributes_8h.html#ace3a72289effba7c41de4a566bd3c300a832294ab11474e3f807c5eaa92b63058',1,'PlantAttributes.h']]]
];
