var searchData=
[
  ['basestrategy_1144',['baseStrategy',['../d4/d46/classFilteredTraversal.html#a09af992d36858919641b6665455c3d82',1,'FilteredTraversal']]],
  ['busy_1145',['busy',['../dd/df7/classStaff.html#a55384f134e49f9fce2054fb3c59ab40d',1,'Staff']]]
];
