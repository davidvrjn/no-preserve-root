var searchData=
[
  ['no_5fsaves_1258',['NO_SAVES',['../df/d0a/main_8cpp.html#a64e169b6e0f42914937270604cc438edaf82e95a8a8acf4640c278ca92b4f1d13',1,'main.cpp']]]
];
