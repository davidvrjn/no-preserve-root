var searchData=
[
  ['name_1185',['name',['../d0/db7/classGroup.html#abfa8bde619513cf0768c14f2e5beeca1',1,'Group::name()'],['../d9/d6e/classPlant.html#afc44bc432916dc4395c747c71867efa2',1,'Plant::name()'],['../d5/d30/structUI_1_1PlantView.html#a943e42934ac62760ba6fc2e089bbf118',1,'UI::PlantView::name()']]],
  ['nextid_1186',['nextId',['../d9/d12/classCustomer.html#a77f4bf375749f8155a59051d3175c785',1,'Customer::nextId()'],['../d0/db2/classInventoryComponent.html#ad1f7ba2ac3b29dac45622292b89f1c19',1,'InventoryComponent::nextId()']]],
  ['nextid_5f_1187',['nextId_',['../da/d06/classLoggingCommand.html#a51aecdba7ceba73c157d5844fa3ff94b',1,'LoggingCommand']]],
  ['nursery_1188',['nursery',['../df/d67/classFertilizeCommand.html#a3f248b161c30f0872da47403e5d79524',1,'FertilizeCommand::nursery()'],['../d0/d53/classFulfillCustomerCommand.html#af2349f4d4c6290d0d7380c4ddfc3897e',1,'FulfillCustomerCommand::nursery()'],['../dd/d93/classNurserySupervisor.html#a6c357f20fd5ea34eaae120112e5a4ccf',1,'NurserySupervisor::nursery()']]]
];
