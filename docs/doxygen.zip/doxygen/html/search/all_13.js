var searchData=
[
  ['validatesavefile_508',['validateSaveFile',['../d9/d2b/classSaveSystem.html#a39f011c9e8c080b5045f347e88396d86',1,'SaveSystem']]],
  ['very_5flow_509',['VERY_LOW',['../d1/d69/PlantAttributes_8h.html#acacbee97732ff15c4415b2037a4d7a94ab8756489d86141704f99b4c2a999d5c3',1,'PlantAttributes.h']]]
];
