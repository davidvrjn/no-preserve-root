var classObserver =
[
    [ "~Observer", "de/dab/classObserver.html#a37824643eeaef086de17bba2717d865a", null ],
    [ "update", "de/dab/classObserver.html#af97fc9d0942e9610d0f83bc2f0077346", null ]
];