var classCashier =
[
    [ "Cashier", "de/d14/classCashier.html#a9dd99a4a5f4c5295aaa4584b21e30aec", null ],
    [ "~Cashier", "de/d14/classCashier.html#a94c37cedcd46d600804ea7443d16b182", null ],
    [ "handleRequest", "de/d14/classCashier.html#afa265a070c95122c603603a2e01ef3eb", null ]
];