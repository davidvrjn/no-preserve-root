var classStaff =
[
    [ "Staff", "dd/df7/classStaff.html#a8e1c1bc61b5e0b28053648d51416a8fc", null ],
    [ "~Staff", "dd/df7/classStaff.html#a01b1c732b851db4685c1daad4ea2cdc7", null ],
    [ "getSuccessor", "dd/df7/classStaff.html#ae916b0b4327b7cae7a50d1f0f8cc7d20", null ],
    [ "handleRequest", "dd/df7/classStaff.html#a0e59d9533cfceb14e2c28b38874afd01", null ],
    [ "isBusy", "dd/df7/classStaff.html#a6899930d98841d66a21990c1a132fbdd", null ],
    [ "setBusy", "dd/df7/classStaff.html#a83199fc69cb6110641ab2cfd1f1fc514", null ],
    [ "setSuccessor", "dd/df7/classStaff.html#a9c444a06f4a66aef9c81f0a8538116d0", null ],
    [ "busy", "dd/df7/classStaff.html#a55384f134e49f9fce2054fb3c59ab40d", null ],
    [ "successor", "dd/df7/classStaff.html#ad6a84e9db1ee0e68431cf161d7fd49eb", null ]
];