var structMemento_1_1NurseryState =
[
    [ "day", "dd/d82/structMemento_1_1NurseryState.html#a5b7c6d699dcc649b76255794d383d51d", null ],
    [ "serializedData", "dd/d82/structMemento_1_1NurseryState.html#a7915ae4470f85d0f5b31d06006c91ef9", null ]
];