var classIvy =
[
    [ "Ivy", "d5/dd5/classIvy.html#a03cada04e9279d8493627b6030aa2244", null ],
    [ "~Ivy", "d5/dd5/classIvy.html#a0af8989f954c45d93c86531aaa1562cd", null ],
    [ "blueprintClone", "d5/dd5/classIvy.html#a00c0416094c7f56ecd9dcd230476a7db", null ],
    [ "clone", "d5/dd5/classIvy.html#a348c2ed744e9bc3bb76a000ac4de2df2", null ],
    [ "deserialize", "d5/dd5/classIvy.html#ab01a4eee507bcdde0b5fa7dad69ec127", null ],
    [ "serialize", "d5/dd5/classIvy.html#aecd9c5390971c93b5c775ad7e97112e4", null ],
    [ "typeName", "d5/dd5/classIvy.html#abed374fc55b934a61ce9ad033a13b890", null ],
    [ "water", "d5/dd5/classIvy.html#a6b95659e7ab6132ce4212dca4f507f0e", null ]
];