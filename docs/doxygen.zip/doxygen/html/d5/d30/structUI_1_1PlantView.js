var structUI_1_1PlantView =
[
    [ "age", "d5/d30/structUI_1_1PlantView.html#aac09f205bd38dc437ab3dedb3b00cb01", null ],
    [ "id", "d5/d30/structUI_1_1PlantView.html#a7f4047acc93cbf272b9c42ee180455f6", null ],
    [ "name", "d5/d30/structUI_1_1PlantView.html#a943e42934ac62760ba6fc2e089bbf118", null ],
    [ "state", "d5/d30/structUI_1_1PlantView.html#a750886007ce6c04320cfd69cb488e8a6", null ],
    [ "type", "d5/d30/structUI_1_1PlantView.html#a6b2bbbc2370af6dceeb82ce0bdb046fd", null ]
];