var examples =
[
    [ "/home/david/no-preserve-root/include/Patterns/Iterator/FilteredTraversal.h", "d8/da7/_2home_2david_2no-preserve-root_2include_2Patterns_2Iterator_2FilteredTraversal_8h-example.html", null ],
    [ "/home/david/no-preserve-root/src/Components/Group.cpp", "db/d9f/_2home_2david_2no-preserve-root_2src_2Components_2Group_8cpp-example.html", null ]
];