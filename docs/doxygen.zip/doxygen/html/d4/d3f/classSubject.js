var classSubject =
[
    [ "~Subject", "d4/d3f/classSubject.html#af9723476c61afcceeb91bee3211258c7", null ],
    [ "attach", "d4/d3f/classSubject.html#aad21753583b139e6e095254fd13854bb", null ],
    [ "detach", "d4/d3f/classSubject.html#ae6c5aa09dde33f86abf1e2cb19d1a7d8", null ],
    [ "detachAllObservers", "d4/d3f/classSubject.html#a2bb61b533f72ee593287a2b52bfcfb7d", null ],
    [ "notify", "d4/d3f/classSubject.html#aedd8aa6de28b18ef5880566de4294bfe", null ]
];