var structCommandLogEntry =
[
    [ "Phase", "d4/ddf/structCommandLogEntry.html#a819058ec8429f2b13a7206ba02f13c3d", [
      [ "Pending", "d4/ddf/structCommandLogEntry.html#a819058ec8429f2b13a7206ba02f13c3da2d13df6f8b5e4c5af9f87e0dc39df69d", null ],
      [ "Completed", "d4/ddf/structCommandLogEntry.html#a819058ec8429f2b13a7206ba02f13c3da07ca5050e697392c9ed47e6453f1453f", null ],
      [ "Failed", "d4/ddf/structCommandLogEntry.html#a819058ec8429f2b13a7206ba02f13c3dad7c8c85bf79bbe1b7188497c32c3b0ca", null ]
    ] ],
    [ "executedStep", "d4/ddf/structCommandLogEntry.html#aa60fd5e76ebbccc601c002abf7cfd4f4", null ],
    [ "id", "d4/ddf/structCommandLogEntry.html#a87d7654dc453b607e480ad01e2fbf22b", null ],
    [ "phase", "d4/ddf/structCommandLogEntry.html#a0455a0412540df2a0c01f04658b1c59b", null ],
    [ "step", "d4/ddf/structCommandLogEntry.html#a6f460c879cbb86ee96ba3e7c192975af", null ],
    [ "text", "d4/ddf/structCommandLogEntry.html#afeee65cb2418f2a4d3fe0ebdd1137770", null ],
    [ "timestamp", "d4/ddf/structCommandLogEntry.html#a321eb4f07d39cab2c8eafc7bff9e1889", null ]
];