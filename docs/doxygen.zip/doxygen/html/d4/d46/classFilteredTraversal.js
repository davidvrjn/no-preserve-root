var classFilteredTraversal =
[
    [ "FilteredTraversal", "d4/d46/classFilteredTraversal.html#a97a324c58e1a5326e23140cb4c380415", null ],
    [ "traverse", "d4/d46/classFilteredTraversal.html#a96785880d1d7f3d4ba0c140a36ff3eb5", null ],
    [ "baseStrategy", "d4/d46/classFilteredTraversal.html#a09af992d36858919641b6665455c3d82", null ],
    [ "predicate", "d4/d46/classFilteredTraversal.html#a9ae8d63a830421d2d7ebbc2308ebfb4d", null ]
];