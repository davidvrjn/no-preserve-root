var classBasil =
[
    [ "Basil", "d3/d14/classBasil.html#ae90d9d8f4f7fe2230c9cc434a98887af", null ],
    [ "~Basil", "d3/d14/classBasil.html#a7da50f8c49b305663247e6deede9c727", null ],
    [ "blueprintClone", "d3/d14/classBasil.html#a434e450647c79b490028714b0a646c39", null ],
    [ "clone", "d3/d14/classBasil.html#a1dccbbe117353494e65c7f317d188fd1", null ],
    [ "deserialize", "d3/d14/classBasil.html#abb282d4e57e07898279a8114ea2eb70e", null ],
    [ "serialize", "d3/d14/classBasil.html#aff61bfb42722eac3f2144f4412c70477", null ],
    [ "typeName", "d3/d14/classBasil.html#a205623aebfa0e95fdf025b7ce23f361b", null ],
    [ "water", "d3/d14/classBasil.html#a7b02055410ec6b948b7a028fd910e8f2", null ]
];