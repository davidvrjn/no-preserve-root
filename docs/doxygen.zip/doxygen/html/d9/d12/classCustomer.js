var classCustomer =
[
    [ "Customer", "d9/d12/classCustomer.html#abcc8fae9701e5ba9d7d6fe44498b34e3", null ],
    [ "~Customer", "d9/d12/classCustomer.html#ad3883f226897e5b637420dda65e11eaa", null ],
    [ "getId", "d9/d12/classCustomer.html#a7e896499ffdc0183ed34765ebb2caa31", null ],
    [ "id", "d9/d12/classCustomer.html#a3fe59a5b65c1e46827e92aadf46132b8", null ],
    [ "nextId", "d9/d12/classCustomer.html#a77f4bf375749f8155a59051d3175c785", null ]
];