var classSaveSystem =
[
    [ "SaveSystem", "d9/d2b/classSaveSystem.html#a8adaf73164a861fb67b3bb0d9eb5be4b", null ],
    [ "~SaveSystem", "d9/d2b/classSaveSystem.html#ae7dece837339b225c27d35c56573bfdf", null ],
    [ "fileExists", "d9/d2b/classSaveSystem.html#a18c8d1fcbf28b08f5a0d3b354ba62889", null ],
    [ "getSaveDay", "d9/d2b/classSaveSystem.html#a85ce185ec52958c49352e4b35cce82a6", null ],
    [ "load", "d9/d2b/classSaveSystem.html#a47a5226cb48534cc218f2090be09bd7e", null ],
    [ "prettyPrintSave", "d9/d2b/classSaveSystem.html#ac2177d2073001c12f15ea27635c7fd3c", null ],
    [ "save", "d9/d2b/classSaveSystem.html#aa00bcc170f7670f26eadac843d2b8a62", null ],
    [ "validateSaveFile", "d9/d2b/classSaveSystem.html#a39f011c9e8c080b5045f347e88396d86", null ]
];