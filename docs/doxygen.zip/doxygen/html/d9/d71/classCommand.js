var classCommand =
[
    [ "Status", "d9/d71/classCommand.html#ad959cf59e3d6e4ab98217d5e8957fccf", [
      [ "Pending", "d9/d71/classCommand.html#ad959cf59e3d6e4ab98217d5e8957fccfa2d13df6f8b5e4c5af9f87e0dc39df69d", null ],
      [ "Completed", "d9/d71/classCommand.html#ad959cf59e3d6e4ab98217d5e8957fccfa07ca5050e697392c9ed47e6453f1453f", null ],
      [ "Failed", "d9/d71/classCommand.html#ad959cf59e3d6e4ab98217d5e8957fccfad7c8c85bf79bbe1b7188497c32c3b0ca", null ],
      [ "Cancelled", "d9/d71/classCommand.html#ad959cf59e3d6e4ab98217d5e8957fccfaa149e85a44aeec9140e92733d9ed694e", null ]
    ] ],
    [ "~Command", "d9/d71/classCommand.html#aa545a53d35818f9efb936daf3fa16c61", null ],
    [ "execute", "d9/d71/classCommand.html#a6fd7d9bd8df8bfc881e4d6c7cd1878b7", null ],
    [ "getStatus", "d9/d71/classCommand.html#a484322ed9a2a927ef01f0716e0c7c920", null ],
    [ "getTargetId", "d9/d71/classCommand.html#aa3a8c8bf71e4aab8390ee7da63d26180", null ],
    [ "setStatus", "d9/d71/classCommand.html#a2918a5c4f4bd87d8842999b63d529da6", null ],
    [ "setTargetId", "d9/d71/classCommand.html#afcce8f5fd8a850dbd5471903aa54622a", null ],
    [ "toString", "d9/d71/classCommand.html#a148b537424160b827bbb3c6434899682", null ]
];