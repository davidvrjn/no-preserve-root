var classPlantRegistry =
[
    [ "create", "d9/d27/classPlantRegistry.html#a5ec3f778943db96ba6f29582a77a7d45", null ],
    [ "getRegistry", "d9/d27/classPlantRegistry.html#a446ead52b55dd8f88214be5ce6b7cd0a", null ],
    [ "isRegistered", "d9/d27/classPlantRegistry.html#af69d04dcb72c9e14fad56600ffc6ec2d", null ],
    [ "registerType", "d9/d27/classPlantRegistry.html#a2ff7b69d72afec3268c0df89061bee80", null ]
];