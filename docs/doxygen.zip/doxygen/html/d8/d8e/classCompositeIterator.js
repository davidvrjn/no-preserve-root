var classCompositeIterator =
[
    [ "CompositeIterator", "d8/d8e/classCompositeIterator.html#a13c8bf34f00c7487d17061423e2dc99f", null ],
    [ "~CompositeIterator", "d8/d8e/classCompositeIterator.html#a3156481ace12572f3f8ff638b0bb9515", null ],
    [ "hasNext", "d8/d8e/classCompositeIterator.html#a38b1942dc41a1f88f259361dd839f424", null ],
    [ "next", "d8/d8e/classCompositeIterator.html#a99f04791853b6b18b3174c14d3708073", null ],
    [ "collection", "d8/d8e/classCompositeIterator.html#a8c7f71b5e274bfd3a6133335d00fc152", null ],
    [ "position", "d8/d8e/classCompositeIterator.html#a65ef4a84552f85193110f9fe1bfdfa84", null ],
    [ "strategy", "d8/d8e/classCompositeIterator.html#a506b16b2f598676a05ccc65fe634724b", null ]
];