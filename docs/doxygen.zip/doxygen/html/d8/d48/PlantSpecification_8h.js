var PlantSpecification_8h =
[
    [ "PlantSpecification", "d7/d2b/structPlantSpecification.html", "d7/d2b/structPlantSpecification" ],
    [ "RequestType", "d8/d48/PlantSpecification_8h.html#ae10b07f2d0feb103db7fe4cfd192e5af", [
      [ "RECOMMENDATION", "d8/d48/PlantSpecification_8h.html#ae10b07f2d0feb103db7fe4cfd192e5afa743489844b361a6b78d5ea41d98f9452", null ],
      [ "PURCHASE", "d8/d48/PlantSpecification_8h.html#ae10b07f2d0feb103db7fe4cfd192e5afa40053bc4cd84397576ef1df916f20151", null ]
    ] ]
];