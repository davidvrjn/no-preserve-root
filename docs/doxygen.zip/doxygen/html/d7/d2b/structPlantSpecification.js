var structPlantSpecification =
[
    [ "PlantSpecification", "d7/d2b/structPlantSpecification.html#ab4b1b2f5d990e4ab78e11a7e5cdb5563", null ],
    [ "decorators", "d7/d2b/structPlantSpecification.html#a848856b5bdf7eab675134de775c9219f", null ],
    [ "explicitName", "d7/d2b/structPlantSpecification.html#a8c4086e5e12c98cf2fa3da00679e0d35", null ],
    [ "requestType", "d7/d2b/structPlantSpecification.html#a528312b0e34e4f2ed67d1781000c10c1", null ],
    [ "seasonReq", "d7/d2b/structPlantSpecification.html#a9594e233f3b8f65a4ab6e59b175a4b6e", null ],
    [ "waterReq", "d7/d2b/structPlantSpecification.html#a4428ca01b412b4fbd9271b4a3fd6a64a", null ]
];