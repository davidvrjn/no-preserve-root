var classTraversalStrategy =
[
    [ "~TraversalStrategy", "d7/dcc/classTraversalStrategy.html#a53c7b22efacca78e58d51ee5ff5344e6", null ],
    [ "traverse", "d7/dcc/classTraversalStrategy.html#a8c6231a1a9e909efdfd56b9f17287355", null ]
];