var PlantAttributes_8h =
[
    [ "Season", "d1/d69/PlantAttributes_8h.html#ace3a72289effba7c41de4a566bd3c300", [
      [ "SPRING", "d1/d69/PlantAttributes_8h.html#ace3a72289effba7c41de4a566bd3c300a2e2302818a996993c08f2f07c9606e79", null ],
      [ "SUMMER", "d1/d69/PlantAttributes_8h.html#ace3a72289effba7c41de4a566bd3c300acc49522c59ab153ffcd4e38b7efc691d", null ],
      [ "FALL", "d1/d69/PlantAttributes_8h.html#ace3a72289effba7c41de4a566bd3c300a479ab1b75080105c17b10096543dc8c5", null ],
      [ "WINTER", "d1/d69/PlantAttributes_8h.html#ace3a72289effba7c41de4a566bd3c300a832294ab11474e3f807c5eaa92b63058", null ],
      [ "YEAR_ROUND", "d1/d69/PlantAttributes_8h.html#ace3a72289effba7c41de4a566bd3c300aa722f29cb3894d5949e4ff0bc65e0435", null ]
    ] ],
    [ "WaterRequirement", "d1/d69/PlantAttributes_8h.html#acacbee97732ff15c4415b2037a4d7a94", [
      [ "VERY_LOW", "d1/d69/PlantAttributes_8h.html#acacbee97732ff15c4415b2037a4d7a94ab8756489d86141704f99b4c2a999d5c3", null ],
      [ "LOW", "d1/d69/PlantAttributes_8h.html#acacbee97732ff15c4415b2037a4d7a94a41bc94cbd8eebea13ce0491b2ac11b88", null ],
      [ "MEDIUM", "d1/d69/PlantAttributes_8h.html#acacbee97732ff15c4415b2037a4d7a94ac87f3be66ffc3c0d4249f1c2cc5f3cce", null ],
      [ "HIGH", "d1/d69/PlantAttributes_8h.html#acacbee97732ff15c4415b2037a4d7a94ab89de3b4b81c4facfac906edf29aec8c", null ]
    ] ],
    [ "waterRequirementToConsumption", "d1/d69/PlantAttributes_8h.html#aba9ac095f8cf8028b0d185adbe431310", null ]
];